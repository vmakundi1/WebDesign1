$(".navtoggle").click(function(e))
{
	$("nav").toggle();
	e.preventDefault();
});